## [1.2.0] 2019-09-18
### Updated dependencies
- `expo@33.0.0` to `expo@34.0.3`
- `expo-font@5.0.1` to `expo-font@6.0.1`
- added `expo-asset@6.0.0`
- `react-native SDK@33.0.0` to `react-native SDK@34.0.0`
- added `react-native-gesture-handler@1.3.0`
- `galio-framework@0.5.3` to `galio-framework@0.6.1`

## [1.1.0] 2019-06-21
### Updated dependencies
- `expo@32.0.0` to `expo@33.0.0`
- `galio-framework@0.5.1` to `galio-framework@0.5.3`
- `react-native SDK@32.0.0` to `react-native SDK@33.0.0`
- `react-navigation@3.8.1` to `react-navigation@3.11.0`
- `react@16.5.0` to `react@16.8.3`
- added `expo-font@5.0.1`


## [1.0.0] 2019-06-07
### Initial Release